package net.zlysie.engine;

public class ModelTexture {

	private int textureID;

	public ModelTexture(int textureID) {
		this.textureID = textureID;
	}

	public int getID() {
		return textureID;
	}
}
