package net.zlysie.engine.renderers.animated;

import org.lwjgl.opengl.GL20;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;

import net.zlysie.engine.renderers.ShaderProgram;

public class AnimatedModelShader extends ShaderProgram {

	private static final int MAX_JOINTS = 50;// max number of joints in a skeleton
	private static final int DIFFUSE_TEX_UNIT = 0;

	private static final String VERTEX_SHADER = "animatedEntityVertex.glsl";
	private static final String FRAGMENT_SHADER = "animatedEntityFragment.glsl";

	protected int location_projectionViewMatrix;
	protected int location_transformationMatrix;
	protected int location_lightDirection;
	protected int[] location_jointTransforms;
	private int location_diffuseMap;

	/**
	 * Creates the shader program for the {@link AnimatedModelRenderer} by
	 * loading up the vertex and fragment shader code files. It also gets the
	 * location of all the specified uniform variables, and also indicates that
	 * the diffuse texture will be sampled from texture unit 0.
	 */
	public AnimatedModelShader() {
		super(getClass(), VERTEX_SHADER, FRAGMENT_SHADER);
		connectTextureUnits();
	}
	
	@Override
	protected void bindAttributes() {
		super.bindAttribute(0, "in_position");
		super.bindAttribute(1, "in_textureCoords");
		super.bindAttribute(2, "in_normal");
		super.bindAttribute(3, "in_jointIndices");
		super.bindAttribute(4, "in_weights");
	}
	
	@Override
	protected void getAllUniformLocations() {
		location_projectionViewMatrix = super.getUniformLocation("projectionViewMatrix");
		location_transformationMatrix = super.getUniformLocation("transformationMatrix");
		location_lightDirection = super.getUniformLocation("lightDirection");
		location_diffuseMap = super.getUniformLocation("diffuseMap");
		
		location_jointTransforms = new int[MAX_JOINTS];
		for(int i = 0; i < location_jointTransforms.length; i++) {
			location_jointTransforms[i] = super.getUniformLocation("jointTransforms["+i+"]");
		}
	}

	/**
	 * Indicates which texture unit the diffuse texture should be sampled from.
	 */
	private void connectTextureUnits() {
		super.start();
		GL20.glUniform1i(location_diffuseMap, DIFFUSE_TEX_UNIT);
		super.stop();
	}
	
	public void loadProjectionMatrix(Matrix4f projectionMatrix) {
		super.loadMatrix(location_projectionViewMatrix, projectionMatrix);
	}
	
	public void loadTransformationMatrix(Matrix4f transformationMatrix) {
		super.loadMatrix(location_transformationMatrix, transformationMatrix);
	}

	public void loadJointTransforms(Matrix4f[] jointTransforms) {
		for(int i = 0; i < jointTransforms.length; i++) {
			if(jointTransforms[i] != null)
			super.loadMatrix(location_jointTransforms[i], jointTransforms[i]);
		}
		
	}

	public void loadLightDirection(Vector3f lightDir) {
		super.loadVector3(location_lightDirection, lightDir);
	}

	

}
