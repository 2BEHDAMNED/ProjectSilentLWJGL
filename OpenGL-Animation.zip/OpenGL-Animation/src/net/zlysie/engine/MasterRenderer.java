package net.zlysie.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;

import net.zlysie.engine.models.TexturedModel;
import net.zlysie.engine.renderers.normal.StaticRenderer;

public class MasterRenderer {

	private StaticRenderer renderer = new StaticRenderer();
	
	private Map<TexturedModel, List<Entity>> entities = new HashMap<>();
	
	public void render(Light sun, Camera camera) {
		GL11.glClearColor(0.4140625f,0.390625f,0.4375f,1.0f);
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
		
		renderer.prepare();
		renderer.render(entities, sun, camera);
		entities.clear();
	}
	
	public void processEntity(Entity entity) {
		TexturedModel entityModel = entity.getModel();
		List<Entity> batch = entities.get(entityModel);
		if(batch != null) {
			batch.add(entity);
		} else {
			List<Entity> newBatch = new ArrayList<Entity>();
			newBatch.add(entity);
			entities.put(entityModel, newBatch);
		}
	}
	
	public void cleanUp() {
		renderer.cleanUp();
	}
}
