A simple example of skeletal animation using OpenGL (and LWJGL).

To get the code working in an Eclipse project you need to set up a project with the lwjgl, lwjgl_utils,and PNGDecoder jars added to the build path, along with the relevant LWJGL natives.

In case you’ve forgotten how to set up a LWJGL project, you can find a tutorial on how to do that here: https://youtu.be/Jdkq-aSFEA0

You can download PNGDecoder here: http://twl.l33tlabs.org/dist/PNGDecoder.jar
